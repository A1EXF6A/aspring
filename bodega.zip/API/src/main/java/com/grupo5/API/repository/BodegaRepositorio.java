package com.grupo5.API.repository;
import com.grupo5.API.entity.Bodega;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
// BodegaRepositorio.java
public interface BodegaRepositorio extends JpaRepository<Bodega, Long> {
    List<Bodega> findByProductoNombreIgnoreCase(String nombreProducto);
}
