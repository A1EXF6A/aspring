package com.grupo5.API.servicio;

import com.grupo5.API.entity.Bodega;
import com.grupo5.API.repository.BodegaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ProductoService {

    @Autowired
    private BodegaRepositorio bodegaRepositorio;

    public List<Bodega> obtenerStockPorNombre(String nombreProducto) {
        return bodegaRepositorio.findByProductoNombreIgnoreCase(nombreProducto);
    }

    public int obtenerStockTotal(String nombreProducto) {
        return bodegaRepositorio.findByProductoNombreIgnoreCase(nombreProducto)
                .stream()
                .mapToInt(Bodega::getCantidad)
                .sum();
    }
}