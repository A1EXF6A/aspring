package com.grupo5.API.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
// Producto.java
@Entity
@Data
@Table(name = "producto")
public class Producto {
    @Id
    private Long id;
    private String nombre;
}

