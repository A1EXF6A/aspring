package com.grupo5.API.controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.grupo5.API.entity.Bodega;
import com.grupo5.API.servicio.ProductoService;
import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.List;
// ProductoController.java
@Controller
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping("/producto/buscar")
    public String buscarProducto(@RequestParam("nombre") String nombre, Model model) {
        List<Bodega> bodegas = productoService.obtenerStockPorNombre(nombre);
        int total = productoService.obtenerStockTotal(nombre);

        model.addAttribute("productoNombre", nombre);
        model.addAttribute("bodegas", bodegas);
        model.addAttribute("stockTotal", total);

        return "index"; // vista nueva
    }
}

