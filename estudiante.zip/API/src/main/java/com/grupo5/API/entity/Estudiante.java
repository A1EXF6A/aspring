package com.grupo5.API.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Entity
@Data
@Table(name="estudiante")
public class Estudiante {
    @Id
    private String cedula;
    private String nombre;
    private String apellido;
    private String direccion;
    private String telefono;
}
