package com.grupo5.API.repository;

import com.grupo5.API.entity.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EstudianteRepositorio extends JpaRepository<Estudiante, String> {
    List<Estudiante> findByNombreContainingIgnoreCase(String nombre);
}




