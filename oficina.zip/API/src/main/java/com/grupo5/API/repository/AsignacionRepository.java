package com.grupo5.API.repository;

import com.grupo5.API.model.Asignacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AsignacionRepository extends JpaRepository<Asignacion, Long> {
    Optional<Asignacion> findByTrabajadorCedula(String cedula);
}
