package com.grupo5.API.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Trabajador {
    @Id
    private String cedula;
    private String nombre;

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
