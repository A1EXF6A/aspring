package com.grupo5.API.service;

import com.grupo5.API.model.Asignacion;
import com.grupo5.API.model.Oficina;
import com.grupo5.API.model.Trabajador;
import com.grupo5.API.repository.AsignacionRepository;
import com.grupo5.API.repository.OficinaRepository;
import com.grupo5.API.repository.TrabajadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class AsignacionService {

    @Autowired
    private TrabajadorRepository trabajadorRepo;

    @Autowired
    private OficinaRepository oficinaRepo;

    @Autowired
    private AsignacionRepository asignacionRepo;

    public Trabajador crearTrabajador(String cedula, String nombre) {
        Trabajador t = new Trabajador();
        t.setCedula(cedula);
        t.setNombre(nombre);
        return trabajadorRepo.save(t);
    }

    public Oficina crearOficina(String codigo, String direccion) {
        Oficina o = new Oficina();
        o.setCodigo(codigo);
        o.setDireccion(direccion);
        return oficinaRepo.save(o);
    }

    public Asignacion asignarTrabajadorAOficina(String cedula, String codigo) {
        Trabajador t = trabajadorRepo.findById(cedula).orElseThrow(() -> new RuntimeException("Trabajador no encontrado"));
        Oficina o = oficinaRepo.findById(codigo).orElseThrow(() -> new RuntimeException("Oficina no encontrada"));

        Asignacion a = new Asignacion();
        a.setTrabajador(t);
        a.setOficina(o);
        return asignacionRepo.save(a);
    }

    public Oficina buscarOficinaPorCedula(String cedula) {
        return asignacionRepo.findByTrabajadorCedula(cedula)
                .map(Asignacion::getOficina)
                .orElse(null);
    }

    public List<Trabajador> obtenerTodosLosTrabajadores() {
        return trabajadorRepo.findAll();
    }

    public List<Oficina> obtenerTodasLasOficinas() {
        return oficinaRepo.findAll();
    }
}
