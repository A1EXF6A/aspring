package com.grupo5.API.repository;

import com.grupo5.API.model.Oficina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OficinaRepository extends JpaRepository<Oficina, String> {}
