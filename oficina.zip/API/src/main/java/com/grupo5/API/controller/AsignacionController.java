package com.grupo5.API.controller;

import com.grupo5.API.model.Asignacion;
import com.grupo5.API.model.Oficina;
import com.grupo5.API.model.Trabajador;
import com.grupo5.API.service.AsignacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
@RequestMapping("/api")
public class AsignacionController {

    @Autowired
    private AsignacionService service;

    @PostMapping("/trabajadores")
    public ResponseEntity<Trabajador> crearTrabajador(@RequestBody Trabajador t) {
        return ResponseEntity.ok(service.crearTrabajador(t.getCedula(), t.getNombre()));
    }

    @PostMapping("/oficinas")
    public ResponseEntity<Oficina> crearOficina(@RequestBody Oficina o) {
        return ResponseEntity.ok(service.crearOficina(o.getCodigo(), o.getDireccion()));
    }

    @PostMapping("/asignar")
    public ResponseEntity<Asignacion> asignar(@RequestParam String cedula, @RequestParam String codigo) {
        return ResponseEntity.ok(service.asignarTrabajadorAOficina(cedula, codigo));
    }

    @GetMapping("/trabajador/{cedula}/oficina")
    public ResponseEntity<Oficina> obtenerOficina(@PathVariable String cedula) {
        Oficina oficina = service.buscarOficinaPorCedula(cedula);
        return oficina != null ? ResponseEntity.ok(oficina) : ResponseEntity.notFound().build();
    }

    @GetMapping("/trabajadores")
    public ResponseEntity<List<Trabajador>> listarTrabajadores() {
        return ResponseEntity.ok(service.obtenerTodosLosTrabajadores());
    }

    @GetMapping("/oficinas")
    public ResponseEntity<List<Oficina>> listarOficinas() {
        return ResponseEntity.ok(service.obtenerTodasLasOficinas());
    }
}
