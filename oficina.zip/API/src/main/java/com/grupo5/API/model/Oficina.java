package com.grupo5.API.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Oficina {
    @Id
    private String codigo;
    private String direccion;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
