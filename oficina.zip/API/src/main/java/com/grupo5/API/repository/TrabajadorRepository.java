package com.grupo5.API.repository;

import com.grupo5.API.model.Trabajador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrabajadorRepository extends JpaRepository<Trabajador, String> {}
